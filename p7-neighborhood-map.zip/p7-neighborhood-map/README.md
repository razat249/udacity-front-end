## Roomer (Nieghborhood-map)
This web app is used to find rooms/appartments for rent in my area. I am calling it roomer. Anyone having room/appartment for rent can submit a form and the marker will pop up at that location. Others can see the markers and contact the landlord.

## How to run localy
To run this web app locally follow these steps:
- clone this repo to your machine.
- `cd` into the directory.
- run `python -m SimpleHTTPServer 3000`.
- open Browser and head to `localhost:3000`.
